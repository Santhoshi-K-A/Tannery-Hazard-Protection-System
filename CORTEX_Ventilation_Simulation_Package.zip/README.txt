CORTEX ventilation-effectiveness simulation package

Files:
- CORTEX_Ventilation_Effectiveness_Report.pdf: explanation, graph, metrics, limitations
- ventilation_comparison_timeseries.csv: one-second simulated data for both scenarios
- ventilation_summary_metrics.csv: summary metrics
- 01_concentration_off_vs_on.png: main comparison plot
- 02_automatic_fan_response.png: fan-command illustration
- cortex_ventilation_simulation.py: reproducible Python script

Important:
This is a synthetic model only. Values and threshold are arbitrary model units, not ppm or safety limits. No physical sensor, fan, gas, or room was tested. Do not describe the results as measured or validated performance.
