"""
CORTEX ventilation-effectiveness simulation
Illustrative computational model only. No real gas data or sensor calibration.

Model:
    dC/dt = source_rate - k * (C - background)
The assumed ventilation rate constant k is higher when the fan command is ON.
All concentration values and thresholds are arbitrary model units, NOT ppm or safety limits.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DT = 1.0
DURATION_MIN = 30
BACKGROUND = 5.0
RELEASE_START = 3 * 60
RELEASE_END = 8 * 60
SOURCE_RATE = 0.22
K_OFF = 0.0015
K_ON = 0.012
FAN_THRESHOLD = 18.0
FAN_HYSTERESIS = 2.0

t = np.arange(0, DURATION_MIN * 60 + 1, DT)

def simulate(automatic_ventilation):
    c = np.zeros_like(t, dtype=float)
    fan = np.zeros_like(t, dtype=int)
    c[0] = BACKGROUND
    for i in range(1, len(t)):
        previous = c[i - 1]
        if automatic_ventilation:
            if fan[i - 1] == 0 and previous >= FAN_THRESHOLD:
                fan[i] = 1
            elif fan[i - 1] == 1 and previous > FAN_THRESHOLD - FAN_HYSTERESIS:
                fan[i] = 1
            else:
                fan[i] = 0
        source = SOURCE_RATE if RELEASE_START <= t[i] < RELEASE_END else 0.0
        k = K_ON if fan[i] else K_OFF
        c[i] = max(BACKGROUND, previous + (source - k * (previous - BACKGROUND)) * DT)
    return c, fan

off, fan_off = simulate(False)
on, fan_on = simulate(True)

out = pd.DataFrame({
    "time_seconds": t.astype(int),
    "time_minutes": t / 60,
    "release_active": ((t >= RELEASE_START) & (t < RELEASE_END)).astype(int),
    "concentration_model_units_ventilation_off": off,
    "concentration_model_units_ventilation_on": on,
    "fan_command_ventilation_off": fan_off,
    "fan_command_ventilation_on": fan_on,
})
out.to_csv("ventilation_comparison_timeseries.csv", index=False)

plt.figure(figsize=(10, 5.5))
plt.plot(t / 60, off, label="Ventilation OFF", linewidth=2)
plt.plot(t / 60, on, label="Automatic ventilation ON", linewidth=2)
plt.axhline(FAN_THRESHOLD, linestyle="--", label="Illustrative trigger threshold")
plt.axvspan(RELEASE_START / 60, RELEASE_END / 60, alpha=0.12, label="Simulated release period")
plt.xlabel("Time (minutes)")
plt.ylabel("Concentration (arbitrary model units)")
plt.title("CORTEX ventilation-effectiveness simulation")
plt.grid(True, alpha=0.25)
plt.legend()
plt.tight_layout()
plt.savefig("01_concentration_off_vs_on.png", dpi=180)
plt.show()
