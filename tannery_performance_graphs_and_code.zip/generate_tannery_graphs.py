import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

OUT = Path("tannery_graphs")
OUT.mkdir(exist_ok=True)

def save(fig, filename):
    fig.tight_layout()
    fig.savefig(OUT / filename, dpi=300, bbox_inches="tight")
    plt.close(fig)

# Repeated functional trials
trials = np.arange(1, 7)
indices = [20, 24, 45, 52, 75, 86]
conditions = ["Normal", "Normal", "Pre-warning", "Pre-warning", "Danger", "Danger"]
fig, ax = plt.subplots(figsize=(9, 5.2))
bars = ax.bar(trials, indices)
ax.set(title="Repeated Functional Trials: Sensor-Level Index",
       xlabel="Trial", ylabel="Normalized sensor-level index (1–100)")
ax.set_xticks(trials, [f"{i}\\n{c}" for i, c in zip(trials, conditions)])
ax.set_ylim(0, 100); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.0f")
save(fig, "01_repeated_functional_trials.png")

# Response time
response_times = [0.8, 0.9, 1.1, 1.0, 1.2, 1.3]
fig, ax = plt.subplots(figsize=(8.5, 5))
bars = ax.bar(trials, response_times)
ax.set(title="Response Time Across Repeated Functional Trials",
       xlabel="Trial", ylabel="Response time (seconds)")
ax.set_xticks(trials); ax.set_ylim(0, 1.6); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.1f s")
save(fig, "02_response_times.png")

# Working-model ventilation response
times, working_index = [0, 5, 10, 15, 20], [84, 68, 49, 34, 24]
fig, ax = plt.subplots(figsize=(8.5, 5))
ax.plot(times, working_index, marker="o", linewidth=2)
ax.set(title="Working-Model Sensor-Level Index After Ventilation Activation",
       xlabel="Time after ventilation activation (seconds)",
       ylabel="Normalized sensor-level index (1–100)")
ax.set_xticks(times); ax.set_ylim(0, 100); ax.grid(True, alpha=0.3)
for x, y in zip(times, working_index):
    ax.annotate(str(y), (x, y), xytext=(0, 8), textcoords="offset points", ha="center")
save(fig, "03_working_model_ventilation_response.png")

# Scenario peak and RMSE
scenarios = ["Gradual\\nrelease", "Sudden\\nrelease", "Repeated\\nspikes",
             "Intermittent\\nrelease", "Sustained\\nrelease", "Combined\\nrelease"]
peak = [0.784, 1.400, 0.980, 0.860, 0.840, 1.319]
rmse = [0.0431, 0.0952, 0.1035, 0.0617, 0.0309, 0.1016]
fig, ax = plt.subplots(figsize=(10, 5.5))
bars = ax.bar(scenarios, peak)
ax.set(title="Computational Simulation: Peak Modelled Level by Scenario",
       xlabel="Release scenario", ylabel="Peak modelled level (AU)")
ax.set_ylim(0, 1.6); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.3f")
save(fig, "04_scenario_peak_levels.png")

fig, ax = plt.subplots(figsize=(10, 5.5))
bars = ax.bar(scenarios, rmse)
ax.set(title="Computational Simulation: RMSE by Scenario",
       xlabel="Release scenario", ylabel="RMSE (AU)")
ax.set_ylim(0, 0.12); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.4f")
save(fig, "05_scenario_rmse.png")

# OFF vs ON, normalized separately for each metric (OFF = 100%)
metrics = ["Peak modelled\\nconcentration", "Recovery time", "Area above\\nbackground"]
off = [58.18, 15.63, 39123.3]
on = [23.03, 0.45, 11193.9]
on_norm = [v / o * 100 for v, o in zip(on, off)]
x, width = np.arange(len(metrics)), 0.34
fig, ax = plt.subplots(figsize=(9, 5.5))
b1 = ax.bar(x - width/2, [100]*3, width, label="Ventilation OFF")
b2 = ax.bar(x + width/2, on_norm, width, label="Ventilation ON")
ax.set(title="Computational Simulation: Relative Metric Level (OFF = 100%)",
       ylabel="Percentage of ventilation-OFF value (%)")
ax.set_xticks(x, metrics); ax.set_ylim(0, 115)
ax.grid(axis="y", alpha=0.3); ax.legend()
ax.bar_label(b1, padding=3, fmt="%.1f")
ax.bar_label(b2, padding=3, fmt="%.1f")
save(fig, "06_computational_ventilation_comparison.png")

# Reported reductions
names, reductions = ["Peak level", "Recovery time", "Area above\\nbackground"], [60.4, 97.1, 71.4]
fig, ax = plt.subplots(figsize=(8.5, 5))
bars = ax.bar(names, reductions)
ax.set(title="Computational Simulation: Reported Reduction with Ventilation",
       ylabel="Reduction (%)")
ax.set_ylim(0, 110); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.1f%%")
save(fig, "07_computational_reductions.png")

# Event detection summary
fig, ax = plt.subplots(figsize=(7.5, 4.8))
bars = ax.bar(["Detected events", "Undetected events"], [17, 0])
ax.set(title="Computational Event Detection Summary",
       ylabel="Number of simulated events")
ax.set_ylim(0, 20); ax.grid(axis="y", alpha=0.3)
ax.bar_label(bars, padding=3, fmt="%.0f")
save(fig, "08_event_detection_summary.png")
