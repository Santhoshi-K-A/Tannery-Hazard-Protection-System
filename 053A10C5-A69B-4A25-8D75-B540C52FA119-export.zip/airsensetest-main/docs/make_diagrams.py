"""Generate illustration + wiring + architecture diagrams for the Airsense
voice assistant PDF. Pure matplotlib so the images are clean and license-free.
Outputs PNGs into docs/assets/.
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

ASSETS = os.path.join(os.path.dirname(__file__), "assets")
os.makedirs(ASSETS, exist_ok=True)

# ---- shared palette ----
C_ESP = "#2d6cdf"
C_MIC = "#17a673"
C_AMP = "#e67e22"
C_SPK = "#8e44ad"
C_BTN = "#c0392b"
C_BG = "#f4f6fb"
C_EDGE = "#2c3e50"


def _box(ax, x, y, w, h, color, title, lines=None):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
        linewidth=2, edgecolor=C_EDGE, facecolor=color, alpha=0.92))
    ax.text(x + w / 2, y + h - 0.32, title, ha="center", va="top",
            fontsize=12, fontweight="bold", color="white")
    if lines:
        ax.text(x + w / 2, y + h - 0.75, "\n".join(lines), ha="center",
                va="top", fontsize=8.5, color="white")


# =====================================================================
# 1. Components used (labeled illustrations)
# =====================================================================
def components_figure():
    fig, ax = plt.subplots(figsize=(9, 5.2))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    fig.patch.set_facecolor("white")

    # ESP32-S3 board
    _box(ax, 0.4, 3.2, 2.6, 2.2, C_ESP, "ESP32-S3",
         ["MINI-1 DevKit", "WiFi MCU", "2x I2S buses"])
    # draw little header pins
    for i in range(6):
        ax.add_patch(Rectangle((0.5 + i * 0.4, 3.0), 0.12, 0.2,
                     facecolor="#d4af37", edgecolor="none"))
        ax.add_patch(Rectangle((0.5 + i * 0.4, 5.4), 0.12, 0.2,
                     facecolor="#d4af37", edgecolor="none"))

    # INMP441 mic
    _box(ax, 3.7, 4.0, 2.4, 1.6, C_MIC, "INMP441",
         ["I2S MEMS", "microphone", "(audio IN)"])
    ax.add_patch(Circle((4.9, 4.55), 0.16, facecolor="#0d6b4a",
                 edgecolor="white", linewidth=1.5))

    # MAX98357A amp
    _box(ax, 3.7, 1.4, 2.4, 1.6, C_AMP, "MAX98357A",
         ["I2S class-D", "amplifier", "(audio OUT)"])

    # Speaker
    _box(ax, 6.8, 3.6, 2.6, 2.0, C_SPK, "Speaker", ["4-8 ohm", "3 W"])
    ax.add_patch(Circle((8.1, 4.4), 0.5, facecolor="#5e2d78",
                 edgecolor="white", linewidth=2))
    ax.add_patch(Circle((8.1, 4.4), 0.2, facecolor="#3d1d50",
                 edgecolor="white", linewidth=1))

    # Push button
    _box(ax, 6.8, 1.4, 2.6, 1.6, C_BTN, "Push button", ["start a query"])
    ax.add_patch(Circle((8.1, 1.95), 0.22, facecolor="#7b241c",
                 edgecolor="white", linewidth=2))

    ax.set_title("Hardware components used", fontsize=14, fontweight="bold",
                 color=C_EDGE, pad=12)
    fig.tight_layout()
    out = os.path.join(ASSETS, "components.png")
    fig.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


# =====================================================================
# 2. Wiring diagram
# =====================================================================
def wiring_figure():
    fig, ax = plt.subplots(figsize=(9.2, 6.4))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 9)
    ax.axis("off")
    fig.patch.set_facecolor("white")

    # Central ESP32
    ex, ey, ew, eh = 4.2, 3.0, 3.6, 3.2
    ax.add_patch(FancyBboxPatch((ex, ey), ew, eh,
                 boxstyle="round,pad=0.02,rounding_size=0.15",
                 linewidth=2.5, edgecolor=C_EDGE, facecolor=C_ESP, alpha=0.95))
    ax.text(ex + ew / 2, ey + eh - 0.35, "ESP32-S3", ha="center", va="top",
            fontsize=13, fontweight="bold", color="white")

    # pin label helper: returns coordinate of a pin on the ESP box edge
    left_pins = ["G4  SCK", "G5  WS", "G6  SD", "G0  BTN"]
    right_pins = ["BCLK  G15", "LRC  G16", "DIN  G7", "5V / GND"]
    lp_y = {}
    for i, name in enumerate(left_pins):
        y = ey + eh - 1.0 - i * 0.55
        lp_y[name] = y
        ax.plot([ex], [y], marker="s", color="#d4af37", markersize=8)
        ax.text(ex + 0.15, y, name, ha="left", va="center", fontsize=8,
                color="white", fontweight="bold")
    rp_y = {}
    for i, name in enumerate(right_pins):
        y = ey + eh - 1.0 - i * 0.55
        rp_y[name] = y
        ax.plot([ex + ew], [y], marker="s", color="#d4af37", markersize=8)
        ax.text(ex + ew - 0.15, y, name, ha="right", va="center", fontsize=8,
                color="white", fontweight="bold")

    # Microphone block (top-left)
    mx, my, mw, mh = 0.3, 6.6, 3.0, 1.9
    _box(ax, mx, my, mw, mh, C_MIC, "INMP441 mic",
         ["VDD->3V3  GND->GND", "L/R->GND (mono)"])
    mic_pins = {"SCK": my - 0.0, "WS": my - 0.0, "SD": my - 0.0}

    # Amp block (bottom-left)
    ax_, ay, aw, ah = 0.3, 0.4, 3.0, 2.0
    _box(ax, ax_, ay, aw, ah, C_AMP, "MAX98357A amp",
         ["VIN->5V  GND->GND", "SD open (enabled)"])

    # Speaker (top-right)
    _box(ax, 8.7, 6.6, 3.0, 1.9, C_SPK, "Speaker 4-8ohm",
         ["SPK+ / SPK-", "(bridge output)"])

    # Button (bottom-right)
    _box(ax, 8.7, 0.6, 3.0, 1.7, C_BTN, "Push button",
         ["other leg -> GND", "(INPUT_PULLUP)"])

    def wire(p1, p2, color, lw=2.0):
        ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-", color=color,
                     linewidth=lw, connectionstyle="arc3,rad=0.0"))

    # Mic wires (left pins -> mic bottom)
    wire((ex, lp_y["G4  SCK"]), (mx + 0.6, my), C_MIC)
    wire((ex, lp_y["G5  WS"]), (mx + 1.5, my), C_MIC)
    wire((ex, lp_y["G6  SD"]), (mx + 2.4, my), C_MIC)

    # Amp wires (right pins -> amp)
    wire((ex + ew, rp_y["BCLK  G15"]), (ax_ + aw, ay + ah - 0.2), C_AMP)
    wire((ex + ew, rp_y["LRC  G16"]), (ax_ + aw, ay + ah - 0.6), C_AMP)
    wire((ex + ew, rp_y["DIN  G7"]), (ax_ + aw, ay + ah - 1.0), C_AMP)

    # Amp -> speaker
    wire((ax_ + aw, ay + ah - 0.4), (8.7, 7.2), C_SPK, lw=2.4)

    # Button wire (left pin G0 -> button)
    wire((ex + ew, rp_y["5V / GND"]), (8.7, 1.4), C_BTN)
    wire((ex, lp_y["G0  BTN"]), (ex - 0.6, lp_y["G0  BTN"]), C_BTN)
    ax.add_patch(FancyArrowPatch((ex - 0.6, lp_y["G0  BTN"]), (ex - 0.6, 1.4),
                 arrowstyle="-", color=C_BTN, linewidth=2))
    ax.add_patch(FancyArrowPatch((ex - 0.6, 1.4), (8.7, 1.4),
                 arrowstyle="-", color=C_BTN, linewidth=2))

    ax.set_title("Airsense voice assistant - wiring diagram",
                 fontsize=14, fontweight="bold", color=C_EDGE, pad=10)
    fig.tight_layout()
    out = os.path.join(ASSETS, "wiring.png")
    fig.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


# =====================================================================
# 3. System architecture / data flow
# =====================================================================
def architecture_figure():
    fig, ax = plt.subplots(figsize=(9.4, 4.0))
    ax.set_xlim(0, 13)
    ax.set_ylim(0, 5)
    ax.axis("off")
    fig.patch.set_facecolor("white")

    stages = [
        (0.2, C_BTN, "1. Speak", ["Press button", "mic records 4s", "WAV"]),
        (2.8, C_ESP, "2. ESP32", ["POST WAV", "to /voice", "over WiFi"]),
        (5.4, C_MIC, "3. Whisper", ["Groq STT", "speech -> text"]),
        (8.0, C_AMP, "4. LLM", ["Groq chat +", "live sensor", "context"]),
        (10.6, C_SPK, "5. Piper TTS", ["text -> 16kHz", "WAV -> ESP32", "speaker plays"]),
    ]
    w, h, y = 2.2, 2.4, 1.3
    centers = []
    for x, color, title, lines in stages:
        _box(ax, x, y, w, h, color, title, lines)
        centers.append((x + w, y + h / 2))

    for i in range(len(stages) - 1):
        x0 = stages[i][0] + w
        x1 = stages[i + 1][0]
        yy = y + h / 2
        ax.add_patch(FancyArrowPatch((x0, yy), (x1, yy),
                     arrowstyle="-|>", mutation_scale=18,
                     color=C_EDGE, linewidth=2))

    ax.text(6.5, 0.5, "Backend (Flask) runs stages 3-5 on your computer; "
            "the ESP32 only records and plays audio.",
            ha="center", fontsize=9, style="italic", color=C_EDGE)
    ax.set_title("How it works - end-to-end data flow", fontsize=14,
                 fontweight="bold", color=C_EDGE, pad=10)
    fig.tight_layout()
    out = os.path.join(ASSETS, "architecture.png")
    fig.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out


if __name__ == "__main__":
    print(components_figure())
    print(wiring_figure())
    print(architecture_figure())
    print("Diagrams written to", ASSETS)
