"""Build the Airsense Voice Assistant client documentation PDF.

Run:  backend/.venv/bin/python docs/make_pdf.py
Output: docs/Airsense_Voice_Assistant.pdf
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle,
    PageBreak, HRFlowable, ListFlowable, ListItem, KeepTogether,
)

HERE = os.path.dirname(__file__)
ASSETS = os.path.join(HERE, "assets")
OUT = os.path.join(HERE, "Airsense_Voice_Assistant.pdf")

NAVY = colors.HexColor("#2c3e50")
BLUE = colors.HexColor("#2d6cdf")
GREEN = colors.HexColor("#17a673")
LIGHT = colors.HexColor("#f4f6fb")
CODEBG = colors.HexColor("#1e2530")

# ---------------- styles ----------------
styles = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=20,
                    textColor=NAVY, spaceAfter=10, spaceBefore=6)
H2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=14,
                    textColor=BLUE, spaceAfter=6, spaceBefore=12)
BODY = ParagraphStyle("BODY", parent=styles["BodyText"], fontSize=10.5,
                      leading=15, spaceAfter=6, alignment=TA_LEFT)
CAP = ParagraphStyle("CAP", parent=styles["BodyText"], fontSize=9,
                     textColor=colors.grey, alignment=TA_CENTER, spaceAfter=10)
CODE = ParagraphStyle("CODE", parent=styles["Code"], fontSize=8.2,
                      leading=11, textColor=colors.whitesmoke,
                      backColor=CODEBG, leftIndent=6, rightIndent=6,
                      spaceBefore=2, spaceAfter=2, fontName="Courier")
BULLET = ParagraphStyle("BULLET", parent=BODY, spaceAfter=2)
TITLE = ParagraphStyle("TITLE", parent=styles["Title"], fontSize=30,
                       textColor=NAVY, spaceAfter=4, alignment=TA_CENTER)
SUB = ParagraphStyle("SUB", parent=styles["Title"], fontSize=14,
                     textColor=BLUE, alignment=TA_CENTER, spaceAfter=2)


def img(name, width_mm):
    path = os.path.join(ASSETS, name)
    from PIL import Image as PILImage
    w, h = PILImage.open(path).size
    width = width_mm * mm
    height = width * h / w
    return Image(path, width=width, height=height)


def bullets(items):
    return ListFlowable(
        [ListItem(Paragraph(t, BULLET), leftIndent=10) for t in items],
        bulletType="bullet", start="circle", leftIndent=14)


def code_block(lines):
    """Render monospace code lines on a dark background table cell."""
    para = Paragraph("<br/>".join(
        l.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace(" ", "&nbsp;") for l in lines), CODE)
    tbl = Table([[para]], colWidths=[165 * mm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CODEBG),
        ("BOX", (0, 0), (-1, -1), 0.5, NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return tbl


def spec_table(rows, header):
    data = [header] + rows
    tbl = Table(data, colWidths=None, hAlign="LEFT")
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.2),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c8d0e0")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return tbl


# ---------------- page furniture ----------------
def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#c8d0e0"))
    canvas.line(20 * mm, 15 * mm, 190 * mm, 15 * mm)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.grey)
    canvas.drawString(20 * mm, 10 * mm, "Airsense Voice Assistant")
    canvas.drawRightString(190 * mm, 10 * mm, "Page %d" % doc.page)
    canvas.restoreState()


story = []

# ============ COVER ============
story.append(Spacer(1, 45 * mm))
story.append(Paragraph("Airsense", TITLE))
story.append(Paragraph("Voice Assistant for Air-Quality Monitoring", SUB))
story.append(Spacer(1, 6 * mm))
story.append(HRFlowable(width="60%", thickness=1.5, color=BLUE,
                        hAlign="CENTER"))
story.append(Spacer(1, 6 * mm))
story.append(Paragraph(
    "A voice-controlled IoT assistant built on the ESP32-S3. Ask a question "
    "out loud and hear a spoken answer about your live air-quality data.",
    ParagraphStyle("coverp", parent=BODY, alignment=TA_CENTER,
                   fontSize=12, leading=18)))
story.append(Spacer(1, 10 * mm))
story.append(img("components.png", 150))
story.append(Paragraph("Technical & functional overview prepared for the client",
             CAP))
story.append(PageBreak())

# ============ 1. WHAT IS IT ============
story.append(Paragraph("1. What is the Airsense Voice Assistant?", H1))
story.append(Paragraph(
    "Airsense is a small, self-contained voice assistant for an air-quality "
    "monitoring device. Instead of reading numbers off a screen, the user "
    "simply presses a button, asks a question in plain language, and hears a "
    "natural spoken reply. The assistant knows the device's live readings, so "
    "it can answer questions such as &ldquo;Is the air safe right now?&rdquo; "
    "or &ldquo;What is the current gas level?&rdquo;", BODY))
story.append(Paragraph(
    "The system is split into two parts that work together over your WiFi "
    "network:", BODY))
story.append(bullets([
    "<b>The device (ESP32-S3):</b> a compact microcontroller with a "
    "microphone and a speaker. It records the question and plays the answer.",
    "<b>The backend (a Python program):</b> runs on a computer on the same "
    "network. It does the heavy lifting &ndash; understanding speech, forming "
    "an answer, and generating the spoken voice.",
]))
story.append(Paragraph(
    "This split keeps the hardware cheap and simple while the intelligence "
    "runs where there is more processing power.", BODY))

story.append(Paragraph("Key capabilities", H2))
story.append(bullets([
    "Hands-free, voice-in / voice-out interaction.",
    "Answers grounded in the device's live sensor data (gas level, safety "
    "threshold, system on/off state).",
    "Speech recognition and language understanding via the Groq cloud API.",
    "Natural speech output generated locally with the Piper text-to-speech "
    "engine &ndash; no per-word cloud cost for the voice.",
]))

# ============ 2. HOW IT WORKS ============
story.append(Paragraph("2. How it works", H1))
story.append(Paragraph(
    "Each question travels through five stages, from the user's voice to the "
    "spoken answer:", BODY))
story.append(img("architecture.png", 165))
story.append(Paragraph("End-to-end flow of a single voice query", CAP))
story.append(spec_table([
    ["1. Speak", "User holds the button; the microphone records about four "
     "seconds of audio into a WAV file."],
    ["2. Send", "The ESP32 uploads that recording to the backend's "
     "<b>/voice</b> web address over WiFi."],
    ["3. Transcribe", "The backend sends the audio to Groq's Whisper model, "
     "which converts speech into text."],
    ["4. Answer", "The text, plus the current sensor data, is sent to a Groq "
     "language model that writes a short spoken-style answer."],
    ["5. Speak back", "Piper turns that answer into 16&nbsp;kHz audio, which "
     "is streamed back to the ESP32 and played on the speaker."],
], ["Stage", "What happens"]))
story.append(Spacer(1, 4 * mm))
story.append(Paragraph(
    "If Whisper cannot make out any speech, the backend skips the language "
    "model and instead speaks a short &ldquo;Sorry, I didn't catch "
    "that&rdquo; prompt, so the user always gets feedback.", BODY))

# ============ 3. COMPONENTS ============
story.append(PageBreak())
story.append(Paragraph("3. Hardware components used", H1))
story.append(img("components.png", 160))
story.append(Paragraph("The four main parts and the controller board", CAP))
story.append(spec_table([
    ["ESP32-S3 (MINI-1 DevKit)", "Microcontroller", "The brain of the device. "
     "Connects to WiFi and drives two independent I2S audio buses."],
    ["INMP441", "I2S MEMS microphone", "Captures the user's voice as clean "
     "digital audio (no analog noise)."],
    ["MAX98357A", "I2S class-D amplifier", "Converts the digital answer audio "
     "into a powerful analog signal for the speaker."],
    ["Speaker", "4-8 ohm, ~3 W", "Plays the spoken reply."],
    ["Push button", "Momentary switch", "Press-to-talk trigger that starts a "
     "new query."],
], ["Component", "Type", "Role in the system"]))

# ============ 4. WIRING ============
story.append(PageBreak())
story.append(Paragraph("4. Wiring diagram", H1))
story.append(img("wiring.png", 165))
story.append(Paragraph("Connections between the ESP32-S3 and each component",
             CAP))
story.append(Paragraph("Pin-by-pin connections", H2))
story.append(spec_table([
    ["INMP441  SCK", "GPIO 4", "Microphone bit clock"],
    ["INMP441  WS", "GPIO 5", "Microphone word select (L/R clock)"],
    ["INMP441  SD", "GPIO 6", "Microphone data out to ESP32"],
    ["INMP441  VDD / GND", "3.3V / GND", "Power (3.3V only); L/R pin to GND"],
    ["MAX98357A  BCLK", "GPIO 15", "Amplifier bit clock"],
    ["MAX98357A  LRC", "GPIO 16", "Amplifier word select"],
    ["MAX98357A  DIN", "GPIO 7", "Audio data from ESP32 to amplifier"],
    ["MAX98357A  VIN / GND", "5V / GND", "Power (5V recommended for volume)"],
    ["Speaker + / -", "MAX98357A out", "Bridge output &ndash; neither leg to GND"],
    ["Push button", "GPIO 0 and GND", "Uses internal pull-up; no resistor needed"],
], ["From (component pin)", "To (ESP32)", "Purpose"]))
story.append(Spacer(1, 3 * mm))
story.append(Paragraph("Power & grounding notes", H2))
story.append(bullets([
    "<b>Share a common ground</b> between the ESP32, microphone, amplifier "
    "and power source &ndash; this is the most common cause of &ldquo;no "
    "sound&rdquo; problems.",
    "The INMP441 microphone runs on <b>3.3V only</b>.",
    "Feed the MAX98357A amplifier <b>5V</b> for full, clean volume.",
    "Leave the amplifier's SD (shutdown) pin unconnected; it enables itself "
    "by default. Pulling it low mutes the amplifier.",
]))

# ============ 5. CODE EXPLANATION ============
story.append(PageBreak())
story.append(Paragraph("5. Explanation of the code", H1))
story.append(Paragraph(
    "The project has two code bases: the firmware that runs on the ESP32-S3 "
    "(written in Arduino C++), and the backend server (written in Python). "
    "This section explains what each one does in plain terms.", BODY))

# ---- 5.1 firmware ----
story.append(Paragraph("5.1 Device firmware &ndash; esp32_voice.ino", H2))
story.append(Paragraph(
    "This program turns the ESP32-S3 into a press-to-talk voice terminal. "
    "Its job is deliberately simple: connect to WiFi, listen when the button "
    "is pressed, send the recording to the backend, and play whatever audio "
    "comes back.", BODY))
story.append(Paragraph("<b>Start-up (setup):</b> opens the serial monitor, "
             "configures the button, joins the WiFi network, and initialises "
             "the two I2S audio channels (one for the microphone, one for the "
             "speaker).", BODY))
story.append(code_block([
    "void connectWiFi() {",
    "  WiFi.mode(WIFI_STA);",
    "  WiFi.begin(ssid, password);",
    "  while (WiFi.status() != WL_CONNECTED) { delay(500); }",
    "}",
]))
story.append(Paragraph("<b>Recording a question:</b> when the button is "
             "pressed, the microphone records a few seconds into a WAV buffer "
             "in memory.", BODY))
story.append(code_block([
    "uint8_t* recordQuery(size_t* outSize) {",
    "  Serial.println(\"Listening...\");",
    "  uint8_t* wav = i2sMic.recordWAV(RECORD_SECONDS, outSize);",
    "  return wav;   // caller frees it after sending",
    "}",
]))
story.append(Paragraph("<b>Talking to the backend and playing the reply:</b> "
             "the recording is POSTed to the <b>/voice</b> endpoint. The "
             "response audio is then <b>streamed to the speaker in small "
             "1&nbsp;KB chunks</b> rather than stored whole. This matters: the "
             "ESP32-S3 MINI has limited memory, so streaming lets it play "
             "long answers that would otherwise be too big to hold at once.",
             BODY))
story.append(code_block([
    "int code = http.POST(wav, wavSize);",
    "// skip the 44-byte WAV header, then stream PCM out:",
    "while (http.connected()) {",
    "  int n = stream->readBytes(buf, ...);",
    "  if (n > 0) i2sSpk.write(buf, n);   // play this chunk",
    "}",
]))

# ---- 5.2 backend ----
story.append(PageBreak())
story.append(Paragraph("5.2 Backend server &ndash; main.py", H2))
story.append(Paragraph(
    "The backend is a Flask web server. Besides the voice feature it also "
    "collects live sensor readings from the air-quality device through a few "
    "simple web endpoints:", BODY))
story.append(spec_table([
    ["/", "POST", "Receive the latest gas sensor value"],
    ["/gasdata", "GET", "Read back the latest gas value"],
    ["/system", "POST", "Set the system on/off state"],
    ["/normalvalue", "POST", "Set the &ldquo;normal air&rdquo; threshold"],
    ["/voice", "POST", "The voice assistant &ndash; audio in, audio out"],
], ["Endpoint", "Method", "Purpose"]))
story.append(Spacer(1, 3 * mm))
story.append(Paragraph("<b>The /voice endpoint</b> ties the whole assistant "
             "together in three steps &ndash; transcribe, answer, speak:", BODY))
story.append(code_block([
    "# 1. Speech -> text (Groq Whisper)",
    "transcription = groq_client.audio.transcriptions.create(",
    "        file=(\"query.wav\", audio_bytes), model=STT_MODEL)",
    "",
    "# 2. Build an answer from the live sensor data",
    "reply = answer_question(question)",
    "",
    "# 3. Text -> speech (Piper) and return the WAV",
    "return send_file(synthesize(reply), mimetype=\"audio/wav\")",
]))
story.append(Paragraph("<b>Grounding answers in live data:</b> before calling "
             "the language model, the backend builds a short briefing that "
             "describes the current gas value, the safe threshold, and whether "
             "the system is on. The model is told to reply in one or two spoken "
             "sentences, so answers stay short and natural.", BODY))
story.append(code_block([
    "gas_status = \"high\" if sensor > normal else \"normal\"",
    "context = ( \"You are Airsense... current live data:\"",
    "            f\"gas value: {sensor} (status: {gas_status})\"",
    "            f\"normal threshold: {normal} ...\" )",
]))
story.append(Paragraph("<b>Matching the device's audio format:</b> Piper "
             "produces 22,050&nbsp;Hz audio, but the ESP32 speaker expects "
             "16,000&nbsp;Hz. The backend resamples the voice to 16&nbsp;kHz "
             "before sending it, so the reply plays at the correct speed.",
             BODY))

story.append(Paragraph("5.3 Configuration &ndash; constants.py & system.py", H2))
story.append(bullets([
    "<b>system.py</b> holds server settings: debug mode, host address and "
    "port (0.0.0.0:5000 so the device can reach it over the LAN).",
    "<b>constants.py</b> holds the shared live values: the latest sensor "
    "reading, the system on/off state, and the normal-air threshold.",
    "The Groq API key is kept in a private <b>.env</b> file, not in the code, "
    "so the secret is never shared or committed.",
]))

# ============ 6. RUNNING ============
story.append(Paragraph("6. Running the system", H1))
story.append(Paragraph("Once wired and powered, using the assistant takes "
             "three steps:", BODY))
story.append(bullets([
    "<b>Start the backend</b> on a computer on the same WiFi network. It "
    "loads the voice model and begins listening on port 5000.",
    "<b>Power on the ESP32.</b> It connects to WiFi and prints "
    "&ldquo;Press the button to ask a question.&rdquo;",
    "<b>Press the button and speak.</b> After a short pause the spoken answer "
    "plays through the speaker.",
]))
story.append(Spacer(1, 4 * mm))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor("#c8d0e0")))
story.append(Spacer(1, 2 * mm))
story.append(Paragraph(
    "<i>Note: the ESP32 firmware must point at the backend computer's network "
    "address. If that computer's IP changes, update the address in the "
    "firmware (or assign it a fixed IP) so the device can keep reaching the "
    "server.</i>", ParagraphStyle("note", parent=BODY, fontSize=9.5,
                                   textColor=colors.grey)))


def build():
    doc = SimpleDocTemplate(
        OUT, pagesize=A4,
        leftMargin=20 * mm, rightMargin=20 * mm,
        topMargin=18 * mm, bottomMargin=20 * mm,
        title="Airsense Voice Assistant",
        author="Airsense")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print("Wrote", OUT)


if __name__ == "__main__":
    build()
