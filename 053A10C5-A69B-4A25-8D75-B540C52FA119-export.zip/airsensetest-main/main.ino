#include <LiquidCrystal_I2C.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

int lcdColumns = 16;
int lcdRows = 2;
LiquidCrystal_I2C lcd(0x27, lcdColumns, lcdRows);
#define Red D5
#define Green D6
#define Buzzer D7
#define Relay D0
#define Sensor A0
const char* ssid = "Airsense";
const char* password = "1234567890";

// Backend URLs are fetched at boot from a "raw" JSON config on GitHub, so the
// IP/host can change without reflashing. Edit version/version.json and reset.
// The fetch is mandatory: the device retries until it succeeds before running.
//   Expected JSON, e.g.:
//     { "version": "1.0.0", "baseUrl": "https://air-sense-api.vercel.app/" }
const char* configUrl =
    "https://raw.githubusercontent.com/riz4d/AirSense/refs/heads/main/version/version.json";

// Filled in at boot by fetchConfig() (no defaults; config is required).
String apiUrl = "";
String stateUrl = "";
String configVersion = "unknown";

bool systemOn = false;
float normalAirValue = 0.0;

// Relay/fan state. We only switch the relay when the state actually changes,
// and use a hysteresis margin so a reading hovering near the threshold does
// not make the relay chatter on/off every loop.
bool fanOn = false;
const float HYSTERESIS = 5.0;  // turn on above (normal+5), off below (normal-5)

void setup() {
  Serial.begin(9600);
  lcd.init();
  lcd.backlight();

  pinMode(Green, OUTPUT);
  pinMode(Red, OUTPUT);
  pinMode(Buzzer, OUTPUT);
  pinMode(Relay, OUTPUT);
  pinMode(Sensor, INPUT);

  digitalWrite(Relay, HIGH);  // fan off at startup (active-low relay)

  WiFi.begin(ssid, password);
  lcd.setCursor(0, 0);
  lcd.print("Connecting...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }
  lcd.clear();
  lcd.print("WiFi Connected!");
  delay(1000);
  lcd.clear();

  fetchConfig();
}

// Tries once to fetch + parse the JSON config and build apiUrl / stateUrl.
// Returns true only if a valid baseUrl was loaded.
bool tryFetchConfig() {
  if (WiFi.status() != WL_CONNECTED) return false;

  Serial.printf("Free heap before TLS: %u\n", ESP.getFreeHeap());

  WiFiClientSecure client;
  client.setInsecure();  // GitHub raw is HTTPS; skip cert verification.
  // GitHub doesn't support TLS max-fragment-length, so it needs a full 16K RX
  // buffer; keep the TX buffer small to save heap for the handshake.
  client.setBufferSizes(16384, 512);

  HTTPClient http;
  http.setReuse(false);
  if (!http.begin(client, configUrl)) {
    Serial.println("http.begin() failed (bad URL/TLS init).");
    return false;
  }
  http.setTimeout(15000);
  int code = http.GET();

  bool ok = false;
  if (code <= 0) {
    Serial.printf("Config fetch error (%d): %s\n",
                  code, http.errorToString(code).c_str());
    Serial.printf("Free heap after fail: %u\n", ESP.getFreeHeap());
  } else if (code == HTTP_CODE_OK) {
    String body = http.getString();

    StaticJsonDocument<300> doc;
    DeserializationError error = deserializeJson(doc, body);
    if (!error) {
      const char* base = doc["baseUrl"];
      const char* ver = doc["version"];
      if (base != nullptr && strlen(base) > 0) {
        String baseStr = base;
        if (!baseStr.endsWith("/")) baseStr += "/";  // ensure trailing slash
        apiUrl = baseStr;
        stateUrl = baseStr + "state";
        if (ver != nullptr) configVersion = ver;
        Serial.println("Config version: " + configVersion);
        Serial.println("apiUrl: " + apiUrl);
        Serial.println("stateUrl: " + stateUrl);
        ok = true;
      } else {
        Serial.println("Config missing baseUrl.");
      }
    } else {
      Serial.print("Config JSON parse error: ");
      Serial.println(error.c_str());
    }
  } else {
    Serial.printf("Config fetch failed (%d).\n", code);
  }
  http.end();
  return ok;
}

// Config is mandatory: keep retrying until we get valid backend URLs.
void fetchConfig() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Loading config..");
  while (!tryFetchConfig()) {
    Serial.println("Retrying config fetch in 2s...");
    lcd.setCursor(0, 1);
    lcd.print("Retrying...     ");
    delay(2000);
  }
  lcd.clear();
  lcd.print("Config loaded!");
  delay(1000);
  lcd.clear();
}

void fetchSystemState() {
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient http;
    http.begin(client, stateUrl);
    int httpCode = http.GET();
    if (httpCode > 0) {
      String response = http.getString();
      Serial.println("State response: " + response);

      StaticJsonDocument<300> doc;
      DeserializationError error = deserializeJson(doc, response);
      if (!error) {
        const char* status = doc["status"];
        int state = doc["systemstate"];
        float airValue = doc["normalairValue"];

        if (String(status) == "success") {
          systemOn = (state == 1);
          normalAirValue = airValue;
        }
      } else {
        Serial.print("JSON Parsing Error: ");
        Serial.println(error.c_str());
      }
    } else {
      Serial.println("Failed to fetch system state.");
    }
    http.end();
  } else {
    Serial.println("WiFi not connected.");
  }
}

void checkGasLevel() {
  int sensor = analogRead(Sensor);
  Serial.println(sensor);
  sensor = map(sensor, 0, 1024, 0, 100);

  if (sensor <= normalAirValue) {
    digitalWrite(Green, HIGH);
    digitalWrite(Red, LOW);
    digitalWrite(Buzzer, LOW);
    lcd.setCursor(0, 1);
    lcd.print("Gas value:Normal");
  } else if (sensor > normalAirValue) {
    digitalWrite(Green, LOW);
    digitalWrite(Red, HIGH);
    digitalWrite(Buzzer, HIGH);
    lcd.setCursor(0, 1);
    lcd.print("Gas value:High");
  }

  // Relay with hysteresis + change-only switching so it doesn't chatter.
  if (!fanOn && sensor > normalAirValue + HYSTERESIS) {
    fanOn = true;
    digitalWrite(Relay, LOW);   // fan on (active-low relay)
    Serial.println("Fan ON");
  } else if (fanOn && sensor < normalAirValue - HYSTERESIS) {
    fanOn = false;
    digitalWrite(Relay, HIGH);  // fan off (active-low relay)
    Serial.println("Fan OFF");
  }
  lcd.setCursor(0, 0);
  lcd.print("Value : ");
  lcd.print(sensor);

  if (WiFi.status() == WL_CONNECTED) {
    WiFiClientSecure client;
    client.setInsecure();

    HTTPClient http;
    http.begin(client, apiUrl);
    http.addHeader("Content-Type", "application/json");
    String payload = "{\"sensorValue\":" + String(sensor) + "}";
    int httpCode = http.POST(payload);
    Serial.println(httpCode);
    if (httpCode > 0) {
      Serial.println("Data sent successfully!");
      Serial.println("Response: " + http.getString());
    } else {
      Serial.println("Failed to send data.");
    }

    http.end();
  } else {
    Serial.println("WiFi not connected.");
  }
}

void idleMode() {
  digitalWrite(Green, LOW);
  digitalWrite(Red, LOW);
  digitalWrite(Buzzer, LOW);
  digitalWrite(Relay, HIGH);  // fan off (active-low relay)
  fanOn = false;              // reset so it re-triggers cleanly when turned on
  lcd.setCursor(0, 0);
  lcd.print("System is OFF  ");
  lcd.setCursor(0, 1);
  lcd.print("Idle Mode Active");
}

void loop() {
  fetchSystemState();
  if (systemOn) {
    lcd.clear();
    checkGasLevel();
  } else {
    lcd.clear();
    idleMode();
  }
  delay(1000);
}