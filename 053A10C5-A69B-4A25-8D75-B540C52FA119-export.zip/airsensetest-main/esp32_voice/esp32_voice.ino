/*
 * Airsense Voice Assistant - ESP32-S3
 * ------------------------------------
 * Hardware:
 *   INMP441  I2S MEMS microphone   (audio IN  / I2S RX)
 *   MAX98357A I2S class-D amplifier (audio OUT / I2S TX)
 *
 * Flow:
 *   1. Press the button (or wake) -> record a few seconds from the mic.
 *   2. POST the recorded WAV to the backend /voice endpoint.
 *   3. Backend does speech-to-text + answers + text-to-speech.
 *   4. Backend returns a WAV, which we play back through the speaker.
 *
 * Requires: ESP32 Arduino core 3.x (uses the ESP_I2S library).
 *   Board: "ESP32S3 Dev Module"
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ESP_I2S.h>
#include <Arduino.h>
#include <ArduinoJson.h>

// ---------------- WiFi / backend ----------------
const char* ssid     = "Airsense";
const char* password = "1234567890";

// Instead of hardcoding the backend IP (which changes between restarts /
// networks), we fetch it at boot from a "raw" JSON config on GitHub. Edit that
// file whenever the backend IP changes - no reflashing needed.
//   Expected JSON, e.g.:
//     { "version": "1.0.0", "voiceUrl": "http://172.20.10.7:5000/voice" }
const char* configUrl =
    "https://raw.githubusercontent.com/riz4d/AirSense/refs/heads/main/version/version.json";

// Filled in at boot by fetchVoiceUrl() (no default; config is required).
String voiceUrl = "";
String configVersion = "unknown";

// ---------------- Pins: INMP441 (microphone, I2S RX) ----------------
#define MIC_SCK   4   // INMP441 SCK  (bit clock)
#define MIC_WS    5   // INMP441 WS   (word select / LRCL)
#define MIC_SD    6   // INMP441 SD   (serial data out -> ESP32 in)

// ---------------- Pins: MAX98357A (speaker, I2S TX) ----------------
#define SPK_BCLK  15  // MAX98357A BCLK
#define SPK_LRC   16  // MAX98357A LRC  (word select)
#define SPK_DIN   7   // MAX98357A DIN  (ESP32 out -> amp)

// ---------------- Button to start a query ----------------
#define BUTTON_PIN 0  // BOOT button by default; use a dedicated push button for production

// ---------------- Audio settings ----------------
const uint32_t SAMPLE_RATE   = 16000;  // 16 kHz is plenty for speech
const int      RECORD_SECONDS = 4;     // how long to listen per query

// Two independent I2S peripherals: one for the mic, one for the speaker.
I2SClass i2sMic;
I2SClass i2sSpk;

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("WiFi connected, IP: ");
  Serial.println(WiFi.localIP());
}

// Tries once to fetch + parse the JSON config and set voiceUrl.
// Returns true only if a valid voiceUrl was loaded.
bool tryFetchVoiceUrl() {
  if (WiFi.status() != WL_CONNECTED) return false;

  WiFiClientSecure client;
  client.setInsecure();  // GitHub raw is HTTPS; skip cert verification.

  HTTPClient http;
  http.begin(client, configUrl);
  http.setTimeout(10000);
  int code = http.GET();

  bool ok = false;
  if (code == HTTP_CODE_OK) {
    String body = http.getString();

    StaticJsonDocument<300> doc;
    DeserializationError error = deserializeJson(doc, body);
    if (!error) {
      const char* url = doc["voiceUrl"];
      const char* ver = doc["version"];
      if (url != nullptr && strlen(url) > 0) {
        voiceUrl = url;
        if (ver != nullptr) configVersion = ver;
        Serial.println("Config version: " + configVersion);
        Serial.println("Voice URL from config: " + voiceUrl);
        ok = true;
      } else {
        Serial.println("Config missing voiceUrl.");
      }
    } else {
      Serial.print("Config JSON parse error: ");
      Serial.println(error.c_str());
    }
  } else {
    Serial.printf("Config fetch failed (%d).\n", code);
  }
  http.end();
  return ok;
}

// Config is mandatory: keep retrying until we get a valid voice URL.
void fetchVoiceUrl() {
  Serial.println("Loading config...");
  while (!tryFetchVoiceUrl()) {
    Serial.println("Retrying config fetch in 2s...");
    delay(2000);
  }
  Serial.println("Config loaded.");
}

void setupAudio() {
  // Microphone (RX): dout = -1, din = MIC_SD, no master clock.
  i2sMic.setPins(MIC_SCK, MIC_WS, -1, MIC_SD, -1);
  if (!i2sMic.begin(I2S_MODE_STD, SAMPLE_RATE,
                    I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) {
    Serial.println("Failed to init I2S microphone!");
    while (true) delay(1000);
  }

  // Speaker (TX): dout = SPK_DIN, din = -1.
  i2sSpk.setPins(SPK_BCLK, SPK_LRC, SPK_DIN, -1, -1);
  if (!i2sSpk.begin(I2S_MODE_STD, SAMPLE_RATE,
                    I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) {
    Serial.println("Failed to init I2S speaker!");
    while (true) delay(1000);
  }
  Serial.println("I2S mic + speaker ready.");
}

// Records RECORD_SECONDS of audio into a freshly malloc'd WAV buffer.
// Caller must free() the returned pointer. Returns nullptr on failure.
uint8_t* recordQuery(size_t* outSize) {
  Serial.println("Listening...");
  uint8_t* wav = i2sMic.recordWAV(RECORD_SECONDS, outSize);
  if (wav == nullptr || *outSize == 0) {
    Serial.println("Recording failed.");
    return nullptr;
  }
  Serial.printf("Recorded %u bytes of WAV.\n", (unsigned)*outSize);
  return wav;
}

// Sends the recorded WAV to the backend and plays back the WAV response.
void askAndSpeak(uint8_t* wav, size_t wavSize) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected.");
    return;
  }

  HTTPClient http;
  http.begin(voiceUrl);
  http.addHeader("Content-Type", "audio/wav");
  http.setTimeout(20000);  // STT + answer + TTS can take a few seconds

  int code = http.POST(wav, wavSize);
  Serial.printf("Backend responded: %d\n", code);

  if (code == HTTP_CODE_OK) {
    int len = http.getSize();  // may be -1 if chunked/unknown
    WiFiClient* stream = http.getStreamPtr();

    // Stream the WAV and play it in small chunks. This avoids malloc'ing the
    // whole response (which fails for long replies on the PSRAM-less S3-MINI
    // and caused long answers to be silent).
    static uint8_t buf[1024];  // small fixed playback buffer

    // 1. Read and discard the 44-byte WAV header; we play raw PCM via I2S,
    //    which is already configured for 16 kHz mono 16-bit.
    const int WAV_HEADER = 44;
    int skipped = 0;
    while (skipped < WAV_HEADER && http.connected()) {
      int avail = stream->available();
      if (avail > 0) {
        int want = min((int)sizeof(buf), min(avail, WAV_HEADER - skipped));
        skipped += stream->readBytes(buf, want);
      } else {
        delay(1);
      }
    }

    // 2. Stream the PCM body straight to the speaker, chunk by chunk.
    size_t total = 0;
    while (http.connected() && (len < 0 || (int)total < len - WAV_HEADER)) {
      int avail = stream->available();
      if (avail > 0) {
        int want = sizeof(buf);
        if (len > 0) {
          int remaining = (len - WAV_HEADER) - (int)total;
          want = min(want, remaining);
        }
        int n = stream->readBytes(buf, min(avail, want));
        if (n > 0) {
          i2sSpk.write(buf, n);  // play this chunk
          total += n;
        }
      } else {
        // No data right now: stop if the server finished, else wait briefly.
        if (!stream->connected() && stream->available() == 0) break;
        delay(1);
      }
    }
    Serial.printf("Streamed %u bytes of PCM to speaker.\n", (unsigned)total);
  } else {
    Serial.printf("Voice request failed: %s\n", http.errorToString(code).c_str());
  }
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  connectWiFi();
  fetchVoiceUrl();
  setupAudio();
  Serial.println("Press the button to ask a question.");
}

void loop() {
  // --- Button diagnostic: prints the raw pin state once a second. ---
  // Idle (not pressed) should read 1 (HIGH) because of INPUT_PULLUP.
  // Pressing the button should make it read 0 (LOW).
  static unsigned long lastPrint = 0;
  if (millis() - lastPrint > 1000) {
    lastPrint = millis();
    Serial.printf("BUTTON_PIN (GPIO %d) reads: %d\n",
                  BUTTON_PIN, digitalRead(BUTTON_PIN));
  }

  // Trigger a query on button press (active low).
  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(50);  // debounce
    if (digitalRead(BUTTON_PIN) == LOW) {
      size_t wavSize = 0;
      uint8_t* wav = recordQuery(&wavSize);
      if (wav != nullptr) {
        askAndSpeak(wav, wavSize);
        free(wav);
      }
      // wait for release so we don't re-trigger
      while (digitalRead(BUTTON_PIN) == LOW) delay(10);
    }
  }
  delay(20);
}
