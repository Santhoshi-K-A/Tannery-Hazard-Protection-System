import os
import base64

from mailjet_rest import Client
from jinja2 import Template

# Mailjet credentials come from the environment (see backend/.env).
MAILJET_API_KEY = os.environ.get("MAILJET_API_KEY")
MAILJET_API_SECRET = os.environ.get("MAILJET_API_SECRET")

# Sender + default recipient for alerts.
ALERT_SENDER = os.environ.get("ALERT_SENDER", "airsense@mohamedrizad.me")
ALERT_RECIPIENT = os.environ.get("ALERT_RECIPIENT", "kowja638183@gmail.com")

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gas Value Alert</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: auto; background: white; padding: 20px;
                 border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
    h1 { color: #333; }
    p { color: #555; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Gas Value Alert</h1>
    <p>Dear User,</p>
    <p>The gas value is too high: {{ gas }}</p>
    <p>Please take necessary precautions.</p>
    <p>Best regards,<br>Airsense Team</p>
  </div>
</body>
</html>"""


def send_mail(recipient, gasvalue, attachment_path=None):
    """Send a 'gas too high' alert via Mailjet.

    Returns (status_code, response_json), or (None, {...}) if Mailjet
    credentials are not configured.
    """
    if not (MAILJET_API_KEY and MAILJET_API_SECRET):
        print("Mailjet credentials not set; skipping email.")
        return None, {"status": "error", "message": "Mailjet credentials not configured"}

    mailjet = Client(auth=(MAILJET_API_KEY, MAILJET_API_SECRET), version="v3.1")

    html_content = Template(_HTML_TEMPLATE).render(gas=gasvalue)

    data = {
        "Messages": [
            {
                "From": {"Email": ALERT_SENDER, "Name": "Airsense"},
                "To": [{"Email": recipient, "Name": "User"}],
                "Subject": "The gas value is too high",
                "TextPart": f"Alert from Airsense: gas value is too high ({gasvalue}).",
                "HTMLPart": html_content,
                "Attachments": [],
            }
        ]
    }

    if attachment_path:
        with open(attachment_path, "rb") as f:
            attachment_content = base64.b64encode(f.read()).decode()
        data["Messages"][0]["Attachments"].append(
            {
                "ContentType": "application/pdf",
                "Filename": os.path.basename(attachment_path),
                "Base64Content": attachment_content,
            }
        )

    result = mailjet.send.create(data=data)
    return result.status_code, result.json()
