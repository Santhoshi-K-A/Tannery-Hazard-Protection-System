import io
import os
import numpy as np
from flask import Flask, request, jsonify, send_file
from flask_socketio import SocketIO, emit
from dotenv import load_dotenv
from Api.modules.constants import latest_sensor_value, normalairValue, system_state_val
from Api.modules.system import Debug, Host, Port
from Api.modules.email_alert import send_mail, ALERT_RECIPIENT

# Load configuration (GROQ_API_KEY, PIPER_VOICE, ...) from a local .env file.
load_dotenv()

# Voice assistant deps:
#   pip install groq piper-tts pydub python-dotenv
# Offline TTS uses Piper. Download a voice model (an .onnx + .onnx.json pair),
# e.g. en_US-lessac-medium, from https://huggingface.co/rhasspy/piper-voices
from groq import Groq
from piper import PiperVoice

# Set your Groq API key in the environment (or backend/.env) before running:
#   GROQ_API_KEY="gsk_..."
# Get a free key at https://console.groq.com/keys
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")
if not GROQ_API_KEY:
    raise RuntimeError(
        "GROQ_API_KEY is not set. Add it to backend/.env or export it "
        "before starting the server."
    )
groq_client = Groq(api_key=GROQ_API_KEY)

STT_MODEL = "whisper-large-v3-turbo"   # Groq speech-to-text
LLM_MODEL = "openai/gpt-oss-20b"       # Groq chat model

# Offline text-to-speech (Piper). Point this at your downloaded .onnx voice.
# Override with: export PIPER_VOICE="/path/to/en_US-lessac-medium.onnx"
PIPER_VOICE_PATH = os.environ.get("PIPER_VOICE", "voices/en_US-lessac-medium.onnx")
_piper_voice = PiperVoice.load(PIPER_VOICE_PATH)

# Spoken when Whisper could not make out any speech.
DIDNT_CATCH_MSG = "Sorry, I didn't catch that. Please try again."

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# Tracks whether gas was already high, so we email once per high event
# instead of on every reading while it stays high.
_gas_alert_active = False

@app.route('/', methods=['POST'])
def receive_data():
    global latest_sensor_value, _gas_alert_active
    try:
        data = request.get_json()
        if 'sensorValue' in data:
            latest_sensor_value = data['sensorValue']
            print(f"Received sensor value: {latest_sensor_value}")

            if latest_sensor_value > normalairValue:
                if not _gas_alert_active:
                    print("Gas high; sending email alert...")
                    status, resp = send_mail(ALERT_RECIPIENT, latest_sensor_value)
                    print(f"Email result: {status} {resp}")
                    _gas_alert_active = True
            else:
                # Reset once air returns to normal so the next spike re-alerts.
                _gas_alert_active = False

            socketio.emit('sensor_update', {'sensorValue': latest_sensor_value})
            return jsonify({"status": "success", "receivedValue": latest_sensor_value}), 200
        else:
            return jsonify({"status": "error", "message": "Invalid payload"}), 400
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"status": "error", "message": "Invalid request"}), 400

@app.route('/gasdata', methods=['GET'])
def get_sensor_value():
    if latest_sensor_value is not None:
        return jsonify({"status": "success", "sensorValue": latest_sensor_value}), 200
    else:
        return jsonify({"status": "error", "message": "No data available"}), 404
    
@app.route('/system', methods=['POST'])
def system_state():
    global system_state_val
    try:
        data = request.get_json()
        print(data)
        if 'systemState' in data:
            system_state_val = data['systemState']
            print(f"Received System State: {system_state_val}")
            return jsonify({"status": "success", "receivedValue": system_state_val, "normalairValue": normalairValue}), 200
        else:
            return jsonify({"status": "error", "message": "Invalid payload"}), 400
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"status": "error", "message": "Invalid request"}), 400
@app.route('/state', methods=['GET'])
def get_state():
    if system_state_val is not None:
        return jsonify({"status": "success", "systemstate": system_state_val, "normalairValue":normalairValue}), 200
    else:
        return jsonify({"status": "error", "message": "No data available"}), 404
    
@app.route('/normalvalue', methods=['POST'])
def normal_val():
    global normalairValue
    try:
        data = request.get_json()
        print(data)
        if 'normalairValue' in data:
            normalairValue = data['normalairValue']
            print(f"Received System State: {normalairValue}")
            return jsonify({"status": "success", "receivedValue": normalairValue}), 200
        else:
            return jsonify({"status": "error", "message": "Invalid payload"}), 400
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"status": "error", "message": "Invalid request"}), 400

@app.route('/normalstate', methods=['GET'])
def get_nstate():
    if normalairValue is not None:
        return jsonify({"status": "success", "normalairValue": normalairValue}), 200
    else:
        return jsonify({"status": "error", "message": "No data available"}), 404
def answer_question(text):
    """Ask the Groq LLM, giving it the live Airsense data as context so it can
    answer questions about the current gas reading, system status, etc."""
    gas_status = "unknown"
    if latest_sensor_value is not None:
        gas_status = "high" if latest_sensor_value > normalairValue else "normal"

    context = (
        "You are Airsense, a friendly voice assistant for an air-quality "
        "monitoring device. Answer in one or two short spoken sentences. "
        "Here is the current live data:\n"
        f"- Gas sensor value: {latest_sensor_value} (status: {gas_status})\n"
        f"- Normal air threshold: {normalairValue}\n"
        f"- System state: {'on' if system_state_val == 1 else 'off'}\n"
        "If the question is unrelated to air quality or the device, answer "
        "briefly and helpfully anyway."
    )

    completion = groq_client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": context},
            {"role": "user", "content": text or "Hello"},
        ],
        temperature=0.5,
        max_tokens=512,
        reasoning_effort="low",
    )
    reply = (completion.choices[0].message.content or "").strip()
    if not reply:
        reply = "Sorry, I wasn't able to answer that right now."
    return reply


# The ESP32-S3 firmware initialises its I2S speaker at this rate, so the
# WAV we return must use the same rate or playback will be wrong-speed/silent.
ESP32_PLAYBACK_RATE = 16000


def synthesize(text):
    """Offline text-to-speech with Piper, resampled to 16 kHz mono 16-bit
    so it matches the ESP32-S3's I2S speaker configuration. Returns a
    BytesIO WAV buffer ready to stream to the device."""
    import wave

    # Piper streams raw PCM chunks; collect them and note the source rate.
    pcm = bytearray()
    src_rate = ESP32_PLAYBACK_RATE
    for chunk in _piper_voice.synthesize(text):
        src_rate = chunk.sample_rate
        pcm.extend(chunk.audio_int16_bytes)

    samples = np.frombuffer(bytes(pcm), dtype=np.int16)

    # Linear resample to the ESP32 playback rate if Piper's rate differs.
    if src_rate != ESP32_PLAYBACK_RATE and samples.size:
        n_out = int(round(samples.size * ESP32_PLAYBACK_RATE / src_rate))
        x_old = np.linspace(0.0, 1.0, num=samples.size, endpoint=False)
        x_new = np.linspace(0.0, 1.0, num=n_out, endpoint=False)
        samples = np.interp(x_new, x_old, samples.astype(np.float32))
        samples = samples.astype(np.int16)

    wav_buf = io.BytesIO()
    with wave.open(wav_buf, "wb") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(ESP32_PLAYBACK_RATE)
        wav_file.writeframes(samples.tobytes())
    wav_buf.seek(0)
    return wav_buf


@app.route('/voice', methods=['POST'])
def voice_assistant():
    """Receives a WAV recording from the ESP32-S3, transcribes it,
    answers using live sensor data, and returns spoken audio as WAV."""
    try:
        audio_bytes = request.get_data()
        if not audio_bytes:
            return jsonify({"status": "error", "message": "No audio received"}), 400

        # 1. Speech-to-text with Groq Whisper.
        transcription = groq_client.audio.transcriptions.create(
            file=("query.wav", audio_bytes),
            model=STT_MODEL,
            response_format="text",
        )
        question = (transcription or "").strip()
        print(f"Heard: {question!r}")

        # If Whisper heard nothing, speak a short fallback instead of calling the LLM.
        if not question:
            print("No speech detected; sending fallback prompt.")
            return send_file(synthesize(DIDNT_CATCH_MSG), mimetype="audio/wav")

        # 2. Build an answer from the current Airsense state.
        reply = answer_question(question)
        print(f"Replying: {reply!r}")

        # 3. Offline text-to-speech -> WAV for the ESP32 to play.
        return send_file(synthesize(reply), mimetype="audio/wav")
    except Exception as e:
        print(f"Voice error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@socketio.on('connect')
def handle_connect():
    print("Client connected!")
    if latest_sensor_value is not None:
        emit('sensor_update', {'sensorValue': latest_sensor_value})

if __name__ == '__main__':
    socketio.run(app,debug=Debug, host=Host, port=Port)