"""
CORTEX priority simulation: synthetic gas-level response state machine.

IMPORTANT:
- This is an educational computational model using synthetic data.
- Demo thresholds are arbitrary placeholders, NOT safety limits for ammonia,
  hydrogen sulphide, methane, or any other gas.
- Do not connect this logic to real safety equipment without qualified review,
  gas-specific calibrated sensors, validated setpoints, fail-safe design, and testing.
- The simple concentration dynamics are illustrative and are not a validated
  ventilation/dispersion model.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

rng = np.random.default_rng(20261018)
dt_s, duration_s = 1, 20 * 60
t = np.arange(0, duration_s + dt_s, dt_s)
minutes = t / 60.0
source = np.zeros_like(t, dtype=float)
source[(t >= 180) & (t < 480)] = 0.75
source[(t >= 600) & (t < 900)] = 1.0
kernel = np.exp(-np.arange(0, 31) / 8.0)
kernel /= kernel.sum()
source = np.convolve(source, kernel, mode="same") * 1.4

baseline = 12.0
PREWARNING, DANGER, RESET_MARGIN = 35.0, 55.0, 5.0  # DEMO ONLY
SENSOR_NOISE_SD, SENSOR_DELAY_S = 1.2, 3
VENTILATION_EFFECT, NATURAL_LOSS, MAX_SOURCE_RATE = 0.035, 0.002, 0.20

true_conc = np.zeros_like(t, dtype=float)
true_conc[0] = baseline
ventilation_on = np.zeros_like(t, dtype=bool)
alarm_state = np.zeros_like(t, dtype=int)
for i in range(1, len(t)):
    generation = source[i] * MAX_SOURCE_RATE
    removal = NATURAL_LOSS * max(true_conc[i-1] - baseline, 0)
    fan_removal = VENTILATION_EFFECT * max(true_conc[i-1] - baseline, 0) if ventilation_on[i-1] else 0.0
    true_conc[i] = max(baseline, true_conc[i-1] + generation - removal - fan_removal)

raw = true_conc + rng.normal(0, SENSOR_NOISE_SD, size=len(t))
reading = np.array([raw[max(0, i-SENSOR_DELAY_S)] for i in range(len(t))])

events = []
pre, danger, fan = False, False, False
for i in range(1, len(t)):
    x = reading[i]
    if not danger and x >= DANGER:
        danger = True
        events.append((t[i], "DANGER_ALARM_ON", x))
    elif danger and x <= DANGER-RESET_MARGIN:
        danger = False
        events.append((t[i], "DANGER_ALARM_RESET", x))
    if not pre and x >= PREWARNING:
        pre = True
        events.append((t[i], "PREWARNING_ON", x))
    elif pre and x <= PREWARNING-RESET_MARGIN:
        pre = False
        events.append((t[i], "PREWARNING_RESET", x))
    fan = pre or danger
    ventilation_on[i] = fan
    alarm_state[i] = 2 if danger else (1 if pre else 0)

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(minutes, true_conc, label="Modelled concentration")
ax.plot(minutes, reading, label="Simulated sensor reading", alpha=.75)
ax.axhline(PREWARNING, linestyle="--", label="Demo pre-warning threshold")
ax.axhline(DANGER, linestyle="--", label="Demo danger threshold")
ax.set(xlabel="Time (minutes)", ylabel="Illustrative demo ppm", title="CORTEX gas-response simulation")
ax.grid(True, alpha=.25)
ax.legend()
fig.tight_layout()
plt.show()

print("Synthetic simulation only. Thresholds are not real safety limits.")
print("Peak simulated sensor reading:", round(float(reading.max()), 2), "demo ppm")
print("Seconds with ventilation command ON:", int(ventilation_on.sum()))
print("Events:")
for sec, name, value in events:
    print(f"{sec/60:5.2f} min | {name:20s} | {value:.2f} demo ppm")
